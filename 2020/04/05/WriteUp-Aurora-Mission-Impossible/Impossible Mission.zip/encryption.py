from Crypto.Cipher import AES
from Arica import key,flag
import base64
import gmpy2

from Crypto.Util.number import (
    bytes_to_long,
    long_to_bytes,
    str2long,
    long2str,
    getPrime
)
from Crypto.Random.random import (
    getrandbits,
    randint
)

p = 217534615279223294476101434763509239207
g = 2

def encrypt_flag():
    global flag
    aes = AES.new(key, AES.MODE_ECB)
    flag = adaptmessage(flag)
    c = aes.encrypt(flag)
    print("Here is the encrypted flag: "+str(base64.b64encode(c)))
def encrypt_key():
    p = getPrime(700)
    q = getPrime(1400) 
    n = p*q
    print("""+------------------------------------------------------+
|Attension! Through soical engineering, you got this: |
+------------------------------------------------------+""")
    phi = (p-1)*(q-1)
    while(1):
        e=getPrime(10)
        if(phi%e!=0):
            print("e = "+str(e))
            break
    d = gmpy2.invert(e,phi)
    print("n = "+str(n))
    print("Brooke's partial d: "+ str(int(d) % (2**1050)))
    enc = pow(bytes_to_long(key), e, n)
    return enc

def generateDH(exp):
    return pow(g, exp, p)

def adaptmessage(message):
    return message.ljust(16-len(message)%16+len(message), b"\x00")

def aricaSay(*args):
    print("""+-------------------+
|    Arica said:    |
+-------------------+""")
    print(" ".join(map(str,args)))

def brookeSay(*args):
    print("""+--------------------+
|    Brooke said:    |
+--------------------+""")
    print(" ".join(map(str,args)))

def say2arica(*args):
    print("""+---------------------+
|    Say to Arica:    |
+---------------------+
"""+ " ".join(map(str,args)), end="")
    return input()

def say2brooke(*args):
    print("""+----------------------+
|    Say to Brooke:    |
+----------------------+
""" + " ".join(map(str,args)), end="")
    return input()
