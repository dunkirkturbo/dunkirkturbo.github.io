#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from encryption import *
from conversation import *

banner = """
+--------------------------------------------------+
|HELLO CHALLENGER!                                 |
|                                                  |
|Have you ever seen movies like MISSION IMPOSSIBLE?|
|Unfortunately, You have got a mission that seemed |
|impossible to finish!                             |
|                                                  |
|In the task, you are required to decrypt the      |
|'Most secret' message of Arica, the bank clerk.   |
|                                                  |
|Fortunately, after social engineering you have    |
|hacked in her communication with her boyfriend    |
| Brooke and you have got Brooke's partial         |
|RSA-private-key.                                  |
|                                                  |
|To get the message, you must first establish      |
| communication with Arica through 'DH key exchange|
| protocol', chat with her by saying what Brooke   |
|said, but you need to send the message            |
| "I want to get my AES-key." and the timestamp    |
| after Arica said "What can I do for you?",       |
|then she will give the AES-key encrypted with her |
| RSA-public-key，this message should be start with|
| "Here is the key:".                              |
+--------------------------------------------------+

+---------------------------------------------------------+
| PS:                                                     |
| All message should be followed with new timestamp!!!    |
| newtimestamp = (oldtimestamp+1)%256                     |
| Please don't stuck with it:(                            |
| For example, when you decrypt what Arica said like this:|
| +--------------------+                                  |
| |    Brooke said:    |                                  |
| +--------------------+                                  |
| I'm Brooke.                                             |
| timestamp:112                                           |
| You should encrypt this message to Arica:               |
| +---------------------+                                 |
| |    Say to Arica:    |                                 |
| +---------------------+                                 |
| I'm Brooke.                                             |
| timestamp:113                                           |
+---------------------------------------------------------+
"""

def main():
    print(banner)
    encrypt_flag()
    enc = encrypt_key()
    print("Now the conversation begins. Good luck and enjoy the challenge~")
    expA = getrandbits(128)
    expB = getrandbits(128)
    A = generateDH(expA)
    B = generateDH(expB)
    aricaSay("A:", A)
    AC = int(say2brooke("A: "))
    if(AC <=0):
        brookeSay("You are not Arica! Her public key should not be:", AC)
        exit(0)
    brookeSay("B:", B)
    BC = int(say2arica("B: "))
    if(BC <=0):
        aricaSay("You are not Brooke! His public key should not be:", BC)
        exit(0)
    keyC = pow(AC, expB, p)
    keyS = pow(BC, expA, p)
    keyC = long_to_bytes(keyC).rjust(16, b"\x00")
    keyS = long_to_bytes(keyS).rjust(16, b"\x00")
    cipherC = AES.new(keyC, AES.MODE_ECB)
    cipherS = AES.new(keyS, AES.MODE_ECB)
    for _i in range(5):
        index=_i
        randomnum = randint(0, 255)
        messageA = questions[index]+b"\ntimestamp:"+bytes(str(randomnum),encoding='utf-8')
        messageA = adaptmessage(messageA)
        cS = bytes_to_long(cipherS.encrypt(messageA))
        aricaSay("A:", "{:032x}".format(cS))
        s = int(say2brooke("A: "), 16)
        s = long_to_bytes(s)
        q = cipherC.decrypt(s)
        messageA = questions[index]+b"\ntimestamp:"+bytes(str((randomnum+1)%256),encoding='utf-8')
        messageA = adaptmessage(messageA)
        if q != messageA:
            print("Brooke does't get your words and realize something, U FAILED...")
            exit(0)
        randomnum = randint(0, 256)
        messageB = answer[index]+b"\ntimestamp:"+bytes(str(randomnum),encoding='utf-8')
        messageB = adaptmessage(messageB)
        cC = bytes_to_long(cipherC.encrypt(messageB))
        brookeSay("B:", "{:032x}".format(cC))
        s = int(say2arica("B: "), 16)
        s = long_to_bytes(s)
        a = cipherS.decrypt(s)
        if(_i==4):
            messageB = fake_answer+b"\ntimestamp:"+bytes(str((randomnum+1)%256),encoding='utf-8')
            messageB = adaptmessage(messageB)
        else:
            messageB = answer[index]+b"\ntimestamp:"+bytes(str((randomnum+1)%256),encoding='utf-8')
            messageB = adaptmessage(messageB)
        if a != messageB:
            print("Arica does't get your words and realize something, U FAILED...")
            exit(0)
        
    randomnum = randint(0, 256)
    messageA = saying_key+long_to_bytes(enc)+b"\ntimestamp:"+bytes(str(randomnum),encoding='utf-8')
    messageA = adaptmessage(messageA)
    cS = bytes_to_long(cipherS.encrypt(messageA))
    aricaSay("A:", "{:032x}".format(cS))

if __name__ == "__main__":
    main()
