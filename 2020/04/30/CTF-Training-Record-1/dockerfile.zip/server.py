#!/usr/bin/python
# encoding: utf-8
import sys
import random
from os import urandom
from Crypto.Util.number import *
from secret import flag
#flag='flag'
def my_print(message):
    sys.stdout.write('{0}\n'.format(message))
    sys.stdout.flush()
    sys.stderr.flush()

def read_int():
    return int(sys.stdin.readline().strip())

def read_str():
    return sys.stdin.readline().strip()

def get_choice():
    return int(sys.stdin.readline().strip())

class Game:
    def __init__(self, n, key, r, b):
        self.n = n
        self.key = key 
        self.r = r & (2 ** self.n - 1)
        self.b = b

    def out(self):
        o = self.r & 1
        p = self.r & self.key
        q = 0
        while p:
            q = q + p & 1
            p = p >> 1
        q = q & 1
        t = q << (self.n - 2) & (2 ** self.n - 1)
        self.r = t | (self.r >> 1) & (2 ** self.n - 1)
        return o

    def next(self):
        res = 0
        for i in range(self.b):
            o = self.out()
            res |=  o << (self.b - 1 - i)
        return res

def configure():
    my_print('Please choose the Game Level.')
    a = getPrime(64)
    b = getPrime(64)
    c = getPrime(64)
    d = int(urandom(8).encode('hex'),16)
    code = []
    for i in range(7):
        d = (d * a + c) % b
        code.append(d)
    level = [(500,1),(600,1),(700,1),(800,1),(900,1),(1000,1),(500,10)]
    my_print('Baby:{}'.format(code[0]))
    my_print('Easy:{}'.format(code[1]))
    my_print('Normal:{}'.format(code[2]))
    my_print('Hard:{}'.format(code[3]))
    my_print('Master:{}'.format(code[4]))
    my_print('Crazy:{}'.format(code[5]))
    my_print('Input the level code:')
    l = get_choice()
    if l not in code:
        my_print('No such level.')
        exit(-1)
    else:
        return level[code.index(l)]

def start(coin,flag_coin):
    my_print('Your coins:{}'.format(coin))
    my_print('You can buy a FLAG with {} coins.'.format(flag_coin))
    while True:
        my_print('Input your answer:')
        x = game.next() 
        ans = read_int()
        if ans == x:
            coin += 1
            my_print('Right! The answer is {0}!'.format(x))
            my_print('Your coin: {0}'.format(coin))
        else:
            coin -= 1
            my_print('Wrong! The answer is {0}!'.format(x))
            my_print('Your coin: {0}'.format(coin))

        if coin == flag_coin:
            my_print('You Win!')
            my_print(flag)
            exit(0)
        if coin == 0:
            my_print('Game Over!')
            exit(0)

def my_exit():
    my_print('Bye~')
    exit(0)

if __name__ == '__main__':
    n = 40
    key = int(urandom(n/8).encode('hex'),16)
    r = random.randrange(1, 2 ** (n - 1))
    game = Game(n,key,r,8)
    coin = 0
    flag_coin = 0xdeadbeef
    o = False
    my_print('                                                        ')
    my_print('  ____                        ____                      ')
    my_print(' / ___|_   _  ___  ___ ___   / ___| __ _ _ __ ___   ___ ')
    my_print('| |  _| | | |/ _ \/ __/ __| | |  _ / _` |  _ ` _ \ / _ \\')
    my_print('| |_| | |_| |  __/\__ \__ \ | |_| | (_| | | | | | |  __/')
    my_print(' \____|\__,_|\___||___/___/  \____|\__,_|_| |_| |_|\___|')
    my_print('                                                        ')
    my_print('Welcome to My Guess Game!')
    my_print('====================================',)
    my_print('             Guess Game             ',)
    my_print('====================================',)
    my_print('1. Start                            ',)
    my_print('2. Configure                        ',)
    my_print('3. Exit                             ',)
    my_print('====================================',)
    try:
        while True:
            my_print('Your choice:')
            choice = get_choice()
            if choice == 1:
                if o:
                    start(coin,flag_coin)
                    continue
                else:
                    my_print('Please configure the game first.')
            elif choice == 2:
                if not o:
                    flag_coin,coin = configure()
                    o = True
                    my_print('Done!')
                else:
                    my_print('Only once.')
                continue
            elif choice == 3:
                my_exit()
                continue
            else:
                my_print('Invalid!')
                exit(-1)
    except:
    	exit(-1)
