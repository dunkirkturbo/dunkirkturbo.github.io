from hashlib import md5
from base64 import b64decode
from Crypto.Cipher import AES
from Crypto.Util.number import *

r = 6753785483255906709117615805253027649453460653974415214642466102672301763943358839905575042938258141827000621474498066533397472809407687579125519939754658
ps = []
with open("ps", "r") as f:
    for line in f:
        ps.append(int(line[:-1]))
ps_dict = dict()
for p in ps:
    for i in range(512):
        if ((2**i) & p) != 0:
            ps_dict[i] = p
            break

choose = [0] * 512
for i in range(512):
    if ((2**i) & r) != 0:
        r ^= ps_dict[i]
        choose[ps.index(ps_dict[i])] = 1
choose = int(''.join(str(_) for _ in choose), 2)

key = long_to_bytes(int(md5(long_to_bytes(choose)).hexdigest(), 16))
aes_obj = AES.new(key, AES.MODE_ECB)
cipher = b64decode(b"5eFo3ANg2fu9LRrFktWCJmVvx6RgBFzd0R8GXQ8JD78=")
flag = aes_obj.decrypt(cipher)
print(flag)