import re
from Crypto.Cipher import AES
from binascii import unhexlify
from Crypto.Util.number import *

def getData():
    pqs = []
    with open('prikey', 'r') as fRSA:
        for line in fRSA:
            pq = re.findall(r"\((.*), (.*)\)", line)[0]
            pqs.append((int(pq[0]), int(pq[1])))
    with open('AESkey', 'r') as fAES:
        key = [unhexlify(line.strip()) for line in fAES]
        key = [key[:24], key[24:48], key[48:]]
    with open('new.txt', 'r') as fCIPHER:
        cipher = [unhexlify(line.strip()) for line in fCIPHER]
    return pqs, key, cipher

def dec1(p, q, c, key1, key2):
    aes2 = AES.new(key2, AES.MODE_CBC, iv=b"\x00"*16)
    c = aes2.decrypt(c)
    aes1 = AES.new(key1, AES.MODE_CBC, iv=b"\x00"*16)
    c = bytes_to_long(aes1.decrypt(c))
    e = 17
    n = p * q
    phi = (p - 1) * (q - 1)
    d = inverse(e, phi)
    m = pow(c, d, n)
    return m

def mul(x):
    a = 0
    for i in bin(x)[2:]:
        a = a << 1
        if (int(i)):
            a = a ^ x
        if a >> 256:
            a = a ^ 0x10000000000000000000000000000000000000000000000000000000000000223
    return a

def dec2(m):
    while True:
        m = mul(m)
        if b"flag" in long_to_bytes(m):
            print(long_to_bytes(m))
            break

def main():
    pqs, key, cipher = getData()
    m = dec1(pqs[0][0], pqs[0][1], cipher[0], key[1][0], key[2][0])
    dec2(m)

if __name__ == '__main__':
    main()