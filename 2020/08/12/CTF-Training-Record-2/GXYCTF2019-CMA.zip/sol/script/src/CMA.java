import java.util.Random;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.math.BigInteger;

public class CMA {
    private Random random = new Random();

    public CMA() {
        long PRNG_seed = 0L;
        SeedAttack localSeedAttack = new SeedAttack();
        long d1 = -1029728314L;
        long d2 = 1487023297L;
        try {
            PRNG_seed = localSeedAttack.crack_seed(d1, d2);
//            System.out.println(PRNG_seed);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        this.random.setSeed(PRNG_seed ^ 0x5DEECE66DL);
    }
    // discard trash which generate old.txt
    public void discardTrash() {
        for (int i = 0; i < 19; i++) {
            int j = this.random.nextInt();
        }
    }

    public void genRSA() {
        BigInteger e = BigInteger.valueOf(17L);
        ArrayList<ArrayList> RSA_params = new ArrayList<ArrayList>(24);
        for (int i = 0; i < 24; i++) {
            ArrayList curRSAparams = new ArrayList(2);
            BigInteger p = BigInteger.probablePrime(512, this.random);
            BigInteger q = BigInteger.probablePrime(512, this.random);
            curRSAparams.add(p);
            curRSAparams.add(q);
            RSA_params.add(curRSAparams);
        }
        try {
            PrintWriter localPrintWriter = new PrintWriter("prikey", "UTF-8");
            for (int i = 0; i < 24; i++) {
                ArrayList curRSAparams = RSA_params.get(i);
                String p = curRSAparams.get(0).toString();
                String q = curRSAparams.get(1).toString();
                localPrintWriter.println("(" + p + ", " + q + ")");
            }
            System.out.println("[+] RSA's priKey found");
            localPrintWriter.close();
        } catch (IOException error) {
            error.printStackTrace();
        }
    }

    public static String byte2hex(byte[] paramArrayOfByte)
    {
        StringBuffer localStringBuffer = new StringBuffer(paramArrayOfByte.length * 2);
        for (int i = 0; i < paramArrayOfByte.length; i++)
        {
            if ((paramArrayOfByte[i] & 0xFF) < 16) localStringBuffer.append("0");
            localStringBuffer.append(Long.toString(paramArrayOfByte[i] & 0xFF, 16));
        }
        return localStringBuffer.toString();
    }

    public void genKey() {
        try {
            PrintWriter localPrintWriter = new PrintWriter("AESkey", "UTF-8");
            for (int i = 0; i < 72; i++) {
                byte[] key = new byte[16];
                this.random.nextBytes(key);
                localPrintWriter.println(byte2hex(key));
            }
            System.out.println("[+] AES's key found");
            localPrintWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        CMA exp = new CMA();
        exp.discardTrash();
        exp.genRSA();
        exp.genKey();
    }
}