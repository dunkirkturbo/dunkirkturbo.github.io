public class SeedAttack {
    private long a = 0x5deece66dL;
    private long b = 11L;
    private long m = 0xffffffffffffL;

    public long crack_seed(long d1, long d2) throws Exception {
        for (int i = 0; i <= 0xffff; i++) {
            long seed = (d1 << 16) + i;
            long guess_d2 = (a * seed + b & m) >>> 16;
            if (guess_d2 == d2) {
                System.out.println("[+] PRNG's seed: " + String.valueOf(seed));
                return seed;
            }
        }
        throw new Exception("[!] PRNG crack failed!");
    }

//    public static void main(String[] args) {
//        SeedAttack localSeedAttack = new SeedAttack();
//        long d1 = -1029728314L;
//        long d2 = 1487023297L;
//        try {
//            long seed = localSeedAttack.crack_seed(d1, d2);
//            System.out.println(seed);
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//    }
}